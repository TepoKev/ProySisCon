--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.6
-- Dumped by pg_dump version 10.2 (Debian 10.2-1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE "proy-siscon-db"; Type: COMMENT; Schema: -; Owner: root
--

COMMENT ON DATABASE "proy-siscon-db" IS 'Base de datos usada en el proyecto de sistemas contables';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: cargos_abonos; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE cargos_abonos (
    id integer NOT NULL,
    monto real,
    operacion character varying(1),
    id_cuenta integer,
    id_partida integer
);


ALTER TABLE cargos_abonos OWNER TO root;

--
-- Name: cargos_abonos_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE cargos_abonos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cargos_abonos_id_seq OWNER TO root;

--
-- Name: cargos_abonos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE cargos_abonos_id_seq OWNED BY cargos_abonos.id;


--
-- Name: cuentas; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE cuentas (
    id integer NOT NULL,
    codigo character varying(20),
    nombre character varying(100),
    descripcion character varying(150),
    id_superior integer,
    tipo character varying(1),
    saldo real
);


ALTER TABLE cuentas OWNER TO root;

--
-- Name: cuentas_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE cuentas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cuentas_id_seq OWNER TO root;

--
-- Name: cuentas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE cuentas_id_seq OWNED BY cuentas.id;


--
-- Name: parciales; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE parciales (
    id integer NOT NULL,
    monto real,
    id_cuenta integer,
    id_cargos_abonos integer
);


ALTER TABLE parciales OWNER TO root;

--
-- Name: parciales_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE parciales_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE parciales_id_seq OWNER TO root;

--
-- Name: parciales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE parciales_id_seq OWNED BY parciales.id;


--
-- Name: partidas; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE partidas (
    id integer NOT NULL,
    fecha date,
    descripcion character varying(150),
    contador integer NOT NULL
);


ALTER TABLE partidas OWNER TO root;

--
-- Name: partidas_contador_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE partidas_contador_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE partidas_contador_seq OWNER TO root;

--
-- Name: partidas_contador_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE partidas_contador_seq OWNED BY partidas.contador;


--
-- Name: partidas_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE partidas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE partidas_id_seq OWNER TO root;

--
-- Name: partidas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE partidas_id_seq OWNED BY partidas.id;


--
-- Name: cargos_abonos id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY cargos_abonos ALTER COLUMN id SET DEFAULT nextval('cargos_abonos_id_seq'::regclass);


--
-- Name: cuentas id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY cuentas ALTER COLUMN id SET DEFAULT nextval('cuentas_id_seq'::regclass);


--
-- Name: parciales id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY parciales ALTER COLUMN id SET DEFAULT nextval('parciales_id_seq'::regclass);


--
-- Name: partidas id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY partidas ALTER COLUMN id SET DEFAULT nextval('partidas_id_seq'::regclass);


--
-- Name: partidas contador; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY partidas ALTER COLUMN contador SET DEFAULT nextval('partidas_contador_seq'::regclass);


--
-- Data for Name: cargos_abonos; Type: TABLE DATA; Schema: public; Owner: root
--

COPY cargos_abonos (id, monto, operacion, id_cuenta, id_partida) FROM stdin;
1	500	c	1	16
2	500	a	6	16
3	500	c	1	17
4	500	a	6	17
5	600	c	1	18
6	600	a	6	18
\.


--
-- Data for Name: cuentas; Type: TABLE DATA; Schema: public; Owner: root
--

COPY cuentas (id, codigo, nombre, descripcion, id_superior, tipo, saldo) FROM stdin;
1	1	Activo		\N		\N
2	11	Corriente		1		\N
3	1101	Efectivo y equivalentes de efectivo		2		\N
4	1102	Inversiones financieras a corto plazo		2		\N
5	12	No corriente		1		\N
6	2	Pasivo		\N		\N
7	21	Corriente		6		\N
8	22	No corriente		6		\N
9	3	Patrimonio		\N		\N
10	31	Capital contable		9		\N
11	4	Cuenta de resultados deudoras		\N		\N
12	41	Costos		11		\N
13	42	Gastos		11		\N
14	4201	Gastos de administración		13		\N
15	4202	Gastos de venta		13		\N
16	4203	Costos financieros		13		\N
17	43	Pérdidas		11		\N
18	5	Cuentas de resultado acreedoras		\N		\N
19	51	Ingresos de operación		18		\N
20	52	Ganancias		18		\N
21	6	Cuenta de cierre		\N		\N
22	61	Cuenta liquidadora		21		\N
\.


--
-- Data for Name: parciales; Type: TABLE DATA; Schema: public; Owner: root
--

COPY parciales (id, monto, id_cuenta, id_cargos_abonos) FROM stdin;
\.


--
-- Data for Name: partidas; Type: TABLE DATA; Schema: public; Owner: root
--

COPY partidas (id, fecha, descripcion, contador) FROM stdin;
1	2018-02-21	sistema contable	9
2	\N	short description	11
3	\N	ADS	13
4	\N	asdf	14
5	\N	asdf	15
6	\N	asdf	15
7	\N	asdf	15
8	\N	asdf	15
9	\N	asdf	15
10	\N	ADS	16
11	\N	asdf	17
12	\N	asdf	18
13	\N	ads	19
14	\N	ads	20
15	2018-02-21	ads	22
16	\N	ads	23
17	2018-02-23	ok	24
18	\N	ads	25
\.


--
-- Name: cargos_abonos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('cargos_abonos_id_seq', 1, false);


--
-- Name: cuentas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('cuentas_id_seq', 1, false);


--
-- Name: parciales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('parciales_id_seq', 1, false);


--
-- Name: partidas_contador_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('partidas_contador_seq', 27, true);


--
-- Name: partidas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('partidas_id_seq', 1, false);


--
-- Name: cargos_abonos cargos_abonos_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY cargos_abonos
    ADD CONSTRAINT cargos_abonos_pkey PRIMARY KEY (id);


--
-- Name: cuentas cuentas_codigo_key; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY cuentas
    ADD CONSTRAINT cuentas_codigo_key UNIQUE (codigo);


--
-- Name: cuentas cuentas_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY cuentas
    ADD CONSTRAINT cuentas_pkey PRIMARY KEY (id);


--
-- Name: parciales parciales_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY parciales
    ADD CONSTRAINT parciales_pkey PRIMARY KEY (id);


--
-- Name: partidas partidas_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY partidas
    ADD CONSTRAINT partidas_pkey PRIMARY KEY (id);


--
-- Name: cargos_abonos cargos_abonos_id_cuenta_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY cargos_abonos
    ADD CONSTRAINT cargos_abonos_id_cuenta_fkey FOREIGN KEY (id_cuenta) REFERENCES cuentas(id);


--
-- Name: cargos_abonos cargos_abonos_id_partida_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY cargos_abonos
    ADD CONSTRAINT cargos_abonos_id_partida_fkey FOREIGN KEY (id_partida) REFERENCES partidas(id);


--
-- Name: cuentas cuentas_id_superior_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY cuentas
    ADD CONSTRAINT cuentas_id_superior_fkey FOREIGN KEY (id_superior) REFERENCES cuentas(id);


--
-- Name: parciales parciales_id_cargos_abonos_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY parciales
    ADD CONSTRAINT parciales_id_cargos_abonos_fkey FOREIGN KEY (id_cargos_abonos) REFERENCES cargos_abonos(id);


--
-- Name: parciales parciales_id_cuenta_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY parciales
    ADD CONSTRAINT parciales_id_cuenta_fkey FOREIGN KEY (id_cuenta) REFERENCES cuentas(id);


--
-- PostgreSQL database dump complete
--

